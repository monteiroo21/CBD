# Lista de todos os pilotos

{d.name=Nino, d.surname=Farina}
{d.name=Luigi, d.surname=Fagioli}
{d.name=Reg, d.surname=Parnell}
{d.name=Yves, d.surname=Cabantous}
{d.name=Louis, d.surname=Rosier}
{d.name=Bob, d.surname=Gerard}
{d.name=Cuth, d.surname=Harrison}
{d.name=Philippe, d.surname=�tancelin}
{d.name=David, d.surname=Hampshire}
{d.name=Brian, d.surname=Shawe Taylor}
{d.name=Johnny, d.surname=Claes}
{d.name=Juan, d.surname=Fangio}
{d.name=Joe, d.surname=Kelly}
{d.name=Prince, d.surname=Bira}
{d.name=David, d.surname=Murray}
{d.name=Geoff, d.surname=Crossley}
{d.name=Toulo, d.surname=de Graffenried}
{d.name=Louis, d.surname=Chiron}
{d.name=Eug�ne, d.surname=Martin}
{d.name=Peter, d.surname=Walker}
{d.name=Leslie, d.surname=Johnson}
{d.name=Joe, d.surname=Fry}
{d.name=Tony, d.surname=Rolt}
{d.name=Alberto, d.surname=Ascari}
{d.name=Raymond, d.surname=Sommer}
{d.name=Luigi, d.surname=Villoresi}
{d.name=Jos� Froil�n, d.surname=Gonz�lez}
{d.name=Robert, d.surname=Manzon}
{d.name=Maurice, d.surname=Trintignant}
{d.name=Franco, d.surname=Rol}
{d.name=Harry, d.surname=Schell}
{d.name=Peter, d.surname=Whitehead}
{d.name=Alfredo, d.surname=Pi�n}
{d.name=Johnnie, d.surname=Parsons}
{d.name=Bill, d.surname=Holland}
{d.name=Mauri, d.surname=Rose}
{d.name=Cecil, d.surname=Green}
{d.name=Joie, d.surname=Chitwood}
{d.name=Lee, d.surname=Wallard}
{d.name=Walt, d.surname=Faulkner}
{d.name=George, d.surname=Connor}
{d.name=Paul, d.surname=Russo}
{d.name=Pat, d.surname=Flaherty}
{d.name=Myron, d.surname=Fohr}
{d.name=Duane, d.surname=Carter}
{d.name=Mack, d.surname=Hellings}
{d.name=Jack, d.surname=McGrath}
{d.name=Troy, d.surname=Ruttman}
{d.name=Gene, d.surname=Hartley}
{d.name=Jimmy, d.surname=Davies}
{d.name=Johnny, d.surname=McDowell}
{d.name=Walt, d.surname=Brown}
{d.name=Travis, d.surname=Webb}
{d.name=Jerry, d.surname=Hoyt}
{d.name=Walt, d.surname=Ader}
{d.name=Jackie, d.surname=Holmes}
{d.name=Jim, d.surname=Rathmann}
{d.name=Henry, d.surname=Banks}
{d.name=Bill, d.surname=Schindler}
{d.name=Bayliss, d.surname=Levrett}
{d.name=Fred, d.surname=Agabashian}
{d.name=Jimmy, d.surname=Jackson}
{d.name=Sam, d.surname=Hanks}
{d.name=Tony, d.surname=Bettenhausen}
{d.name=Dick, d.surname=Rathmann}
{d.name=Duke, d.surname=Dinsmore}
{d.name=Bill, d.surname=Cantrell}
{d.name=Felice, d.surname=Bonetto}
{d.name=Nello, d.surname=Pagani}
{d.name=Toni, d.surname=Branca}
{d.name=Pierre, d.surname=Levegh}
{d.name=Eug�ne, d.surname=Chaboud}
{d.name=Charles, d.surname=Pozzi}
{d.name=Dorino, d.surname=Serafini}
{d.name=Guy, d.surname=Mairesse}
{d.name=Piero, d.surname=Taruffi}
{d.name=Clemente, d.surname=Biondetti}
{d.name=Henri, d.surname=Louveau}
{d.name=Franco, d.surname=Comotti}
{d.name=Consalvo, d.surname=Sanesi}
{d.name=Paul, d.surname=Pietsch}
{d.name=Stirling, d.surname=Moss}
{d.name=Rudi, d.surname=Fischer}
{d.name=George, d.surname=Abecassis}
{d.name=Peter, d.surname=Hirt}
{d.name=Mike, d.surname=Nazaruk}
{d.name=Andy, d.surname=Linden}
{d.name=Bobby, d.surname=Ball}
{d.name=Carl, d.surname=Forberg}
{d.name=Duke, d.surname=Nalon}
{d.name=Gene, d.surname=Force}
{d.name=Carl, d.surname=Scarborough}
{d.name=Bill, d.surname=Mackey}
{d.name=Chuck, d.surname=Stevenson}
{d.name=Chet, d.surname=Miller}
{d.name=Rodger, d.surname=Ward}
{d.name=Cliff, d.surname=Griffith}
{d.name=Bill, d.surname=Vukovich}
{d.name=Joe, d.surname=James}
{d.name=Manny, d.surname=Ayulo}
{d.name=Andr�, d.surname=Pilette}
{d.name=Aldo, d.surname=Gordini}
{d.name=Andr�, d.surname=Simon}
{d.name=Onofre, d.surname=Marim�n}
{d.name=Duncan, d.surname=Hamilton}
{d.name=Philip, d.surname=Fotheringham-Parker}
{d.name=John, d.surname=James}
{d.name=Jacques, d.surname=Swaters}
{d.name=Chico, d.surname=Landi}
{d.name=Ken, d.surname=Richardson}
{d.name=Paco, d.surname=Godia}
{d.name=Georges, d.surname=Grignard}
{d.name=Juan, d.surname=Jover}
{d.name=Jean, d.surname=Behra}
{d.name=Ken, d.surname=Wharton}
{d.name=Alan, d.surname=Brown}
{d.name=Eric, d.surname=Brandon}
{d.name=Lance, d.surname=Macklin}
{d.name=Peter, d.surname=Collins}
{d.name=Hans, d.surname=von Stuck}
{d.name=Toni, d.surname=Ulmen}
{d.name=Max, d.surname=de Terra}
{d.name=Art, d.surname=Cross}
{d.name=Jimmy, d.surname=Bryan}
{d.name=Jimmy, d.surname=Reece}
{d.name=Jim, d.surname=Rigsby}
{d.name=George, d.surname=Fonder}
{d.name=Eddie, d.surname=Johnson}
{d.name=Bob, d.surname=Sweikert}
{d.name=Bob, d.surname=Scott}
{d.name=Mike, d.surname=Hawthorn}
{d.name=Paul, d.surname=Fr�re}
{d.name=Charles, d.surname=de Tornaco}
{d.name=Roger, d.surname=Laurent}
{d.name=Arthur, d.surname=Legat}
{d.name=Robert, d.surname=O'Brien}
{d.name=Tony, d.surname=Gaze}
{d.name=Robin, d.surname=Montgomerie-Charrington}
{d.name=Piero, d.surname=Carini}
{d.name=Dennis, d.surname=Poore}
{d.name=Eric, d.surname=Thompson}
{d.name=Roy, d.surname=Salvadori}
{d.name=Ken, d.surname=Downing}
{d.name=Graham, d.surname=Whitehead}
{d.name=Kenneth, d.surname=McAlpine}
{d.name=Gino, d.surname=Bianco}
{d.name=Tony, d.surname=Crook}
{d.name=Eitel, d.surname=Cantoni}
{d.name=Bill, d.surname=Aston}
{d.name=Fritz, d.surname=Riess}
{d.name=Helmut, d.surname=Niedermayr}
{d.name=Hans, d.surname=Klenk}
{d.name=Ernst, d.surname=Klodwig}
{d.name=Willi, d.surname=Heeks}
{d.name=Adolf, d.surname=Brudes}
{d.name=Marcel, d.surname=Balsa}
{d.name=G�nther, d.surname=Bechem}
{d.name=Rudolf, d.surname=Krause}
{d.name=Rudolf, d.surname=Schoeller}
{d.name=Theo, d.surname=Helfrich}
{d.name=Josef, d.surname=Peters}
{d.name=Dries, d.surname=van der Lof}
{d.name=Jan, d.surname=Flinterman}
{d.name=�lie, d.surname=Bayol}
{d.name=Alberto, d.surname=Crespo}
{d.name=Piero, d.surname=Dusio}
{d.name=Oscar, d.surname=G�lvez}
{d.name=John, d.surname=Barber}
{d.name=Carlos, d.surname=Menditeguy}
{d.name=Pablo, d.surname=Birger}
{d.name=Adolfo, d.surname=Cruz}
{d.name=Jimmy, d.surname=Daywalt}
{d.name=Ernie, d.surname=McCoy}
{d.name=Marshall, d.surname=Teague}
{d.name=Don, d.surname=Freeland}
{d.name=Cal, d.surname=Niday}
{d.name=Johnny, d.surname=Thomson}
{d.name=Johnny, d.surname=Mantz}
{d.name=Roberto, d.surname=Mieres}
{d.name=Fred, d.surname=Wacker}
{d.name=Georges, d.surname=Berger}
{d.name=Jimmy, d.surname=Stewart}
{d.name=Jack, d.surname=Fairman}
{d.name=Ian, d.surname=Stewart}
{d.name=Hans, d.surname=Herrmann}
{d.name=Rodney, d.surname=Nuckey}
{d.name=Wolfgang, d.surname=Seidel}
{d.name=Edgar, d.surname=Barth}
{d.name=Oswald, d.surname=Karch}
{d.name=Theo, d.surname=Fitzau}
{d.name=Kurt, d.surname=Adolff}
{d.name=Erwin, d.surname=Bauer}
{d.name=Ernst, d.surname=Loof}
{d.name=Hermann, d.surname=Lang}
{d.name=Albert, d.surname=Scherrer}
{d.name=Sergio, d.surname=Mantovani}
{d.name=Umberto, d.surname=Maglioli}
{d.name=John, d.surname=Fitch}
{d.name=Luigi, d.surname=Musso}
{d.name=Roger, d.surname=Loyer}
{d.name=Jorge, d.surname=Daponte}
{d.name=Larry, d.surname=Crockett}
{d.name=Ed, d.surname=Elisian}
{d.name=Frank, d.surname=Armi}
{d.name=Pat, d.surname=O'Connor}
{d.name=Len, d.surname=Duncan}
{d.name=Bill, d.surname=Homeier}
{d.name=Danny, d.surname=Kladis}
{d.name=Karl, d.surname=Kling}
{d.name=Jacques, d.surname=Pollet}
{d.name=Don, d.surname=Beauman}
{d.name=Leslie, d.surname=Marr}
{d.name=Leslie, d.surname=Thorne}
{d.name=Horace, d.surname=Gould}
{d.name=Bill, d.surname=Whitehouse}
{d.name=John, d.surname=Riseley-Prichard}
{d.name=Clemar, d.surname=Bucci}
{d.name=Ron, d.surname=Flockhart}
{d.name=Giovanni, d.surname=de Riu}
{d.name=Ottorino, d.surname=Volonterio}
{d.name=Jes�s, d.surname=Iglesias}
{d.name=Eugenio, d.surname=Castellotti}
{d.name=Alberto, d.surname=Uria}
{d.name=Cesare, d.surname=Perdisa}
{d.name=Ted, d.surname=Whiteaway}
{d.name=Al, d.surname=Herman}
{d.name=Chuck, d.surname=Weyant}
{d.name=Shorty, d.surname=Templeman}
{d.name=Keith, d.surname=Andrews}
{d.name=Eddie, d.surname=Russo}
{d.name=Ray, d.surname=Crawford}
{d.name=Al, d.surname=Keller}
{d.name=Johnny, d.surname=Boyd}
{d.name=Hernando, d.surname=da Silva Ramos}
{d.name=Mike, d.surname=Sparken}
{d.name=Jack, d.surname=Brabham}
{d.name=Jean, d.surname=Lucas}
{d.name=Luigi, d.surname=Piotti}
{d.name=Olivier, d.surname=Gendebien}
{d.name=Gerino, d.surname=Gerini}
{d.name=�scar, d.surname=Gonz�lez}
{d.name=Giorgio, d.surname=Scarlatti}
{d.name=Tony, d.surname=Brooks}
{d.name=Bob, d.surname=Veith}
{d.name=Bob, d.surname=Christie}
{d.name=Billy, d.surname=Garrett}
{d.name=Johnnie, d.surname=Tolan}
{d.name=Jack, d.surname=Turner}
{d.name=Piero, d.surname=Scotti}
{d.name=Alfonso, d.surname=de Portago}
{d.name=Colin, d.surname=Chapman}
{d.name=Desmond, d.surname=Titterington}
{d.name=Bruce, d.surname=Halford}
{d.name=Archie, d.surname=Scott Brown}
{d.name=Paul, d.surname=Emery}
{d.name=Andr�, d.surname=Milhoux}
{d.name=Les, d.surname=Leston}
{d.name=Wolfgang, d.surname=von Trips}
{d.name=Jo, d.surname=Bonnier}
{d.name=Alessandro, d.surname=de Tomaso}
{d.name=Masten, d.surname=Gregory}
{d.name=Stuart, d.surname=Lewis-Evans}
{d.name=Ivor, d.surname=Bueb}
{d.name=Don, d.surname=Edmunds}
{d.name=Eddie, d.surname=Sachs}
{d.name=Mike, d.surname=Magill}
{d.name=Bill, d.surname=Cheesbourg}
{d.name=Elmer, d.surname=George}
{d.name=Mike, d.surname=MacDowel}
{d.name=Herbert, d.surname=MacKay-Fraser}
{d.name=Brian, d.surname=Naylor}
{d.name=Carel Godin, d.surname=de Beaufort}
{d.name=Tony, d.surname=Marsh}
{d.name=Paul, d.surname=England}
{d.name=Dick, d.surname=Gibson}
{d.name=Cliff, d.surname=Allison}
{d.name=Graham, d.surname=Hill}
{d.name=Ken, d.surname=Kavanagh}
{d.name=Bruce, d.surname=Kessler}
{d.name=Maria, d.surname=de Filippis}
{d.name=Andr�, d.surname=Testut}
{d.name=Giulio, d.surname=Cabianca}
{d.name=Bernie, d.surname=Ecclestone}
{d.name=Luigi, d.surname=Taramazzo}
{d.name=George, d.surname=Amick}
{d.name=Jud, d.surname=Larson}
{d.name=Dempsey, d.surname=Wilson}
{d.name=Anthony, d.surname=Foyt}
{d.name=Paul, d.surname=Goldsmith}
{d.name=Jerry, d.surname=Unser}
{d.name=Len, d.surname=Sutton}
{d.name=Art, d.surname=Bisch}
{d.name=Phil, d.surname=Hill}
{d.name=Carroll, d.surname=Shelby}
{d.name=Ian, d.surname=Burgess}
{d.name=Alan, d.surname=Stacey}
{d.name=Bruce, d.surname=McLaren}
{d.name=Christian, d.surname=Goethals}
{d.name=Robert, d.surname=La Caze}
{d.name=Andr�, d.surname=Guelfi}
{d.name=Fran�ois, d.surname=Picard}
{d.name=Tom, d.surname=Bridger}
{d.name=Alain, d.surname=de Changy}
{d.name=Lucien, d.surname=Bianchi}
{d.name=Pete, d.surname=Lovely}
{d.name=Jean, d.surname=Lucienbonnet}
{d.name=Chuck, d.surname=Arnold}
{d.name=Jim, d.surname=McWithey}
{d.name=Don, d.surname=Branson}
{d.name=Bobby, d.surname=Grim}
{d.name=Red, d.surname=Amick}
{d.name=Innes, d.surname=Ireland}
{d.name=Fritz, d.surname=d'Orey}
{d.name=Dan, d.surname=Gurney}
{d.name=Colin, d.surname=Davis}
{d.name=Azdrubal, d.surname=Fontes}
{d.name=Chris, d.surname=Bristow}
{d.name=Henry, d.surname=Taylor}
{d.name=Peter, d.surname=Ashdown}
{d.name=David, d.surname=Piper}
{d.name=Mike, d.surname=Taylor}
{d.name=Keith, d.surname=Greene}
{d.name=Bill, d.surname=Moss}
{d.name=Mike, d.surname=Parkes}
{d.name=Dennis, d.surname=Taylor}
{d.name=Trevor, d.surname=Taylor}
{d.name=Tim, d.surname=Parnell}
{d.name=M�rio de Ara�jo, d.surname=Cabral}
{d.name=Harry, d.surname=Blanchard}
{d.name=George, d.surname=Constantine}
{d.name=Bob, d.surname=Said}
{d.name=Phil, d.surname=Cade}
{d.name=Alberto Rodriguez, d.surname=Larreta}
{d.name=Roberto, d.surname=Bonomi}
{d.name=Gino, d.surname=Munaron}
{d.name=Nasif, d.surname=Est�fano}
{d.name=Ettore, d.surname=Chimeri}
{d.name=Antonio, d.surname=Creus}
{d.name=Richie, d.surname=Ginther}
{d.name=John, d.surname=Surtees}
{d.name=Chuck, d.surname=Daigh}
{d.name=Lance, d.surname=Reventlow}
{d.name=Lloyd, d.surname=Ruby}
{d.name=Bud, d.surname=Tingelstad}
{d.name=Jim, d.surname=Hurtubise}
{d.name=Wayne, d.surname=Weiler}
{d.name=Jim, d.surname=Clark}
{d.name=Willy, d.surname=Mairesse}
{d.name=Piero, d.surname=Drogo}
{d.name=Fred, d.surname=Gamble}
{d.name=Alfonso, d.surname=Thiele}
{d.name=Vic, d.surname=Wilson}
{d.name=Arthur, d.surname=Owen}
{d.name=Jim, d.surname=Hall}
{d.name=Bob, d.surname=Drake}
{d.name=Michael, d.surname=May}
{d.name=Jackie, d.surname=Lewis}
{d.name=Lorenzo, d.surname=Bandini}
{d.name=Giancarlo, d.surname=Baghetti}
{d.name=Bernard, d.surname=Collomb}
{d.name=Juan Manuel, d.surname=Bordeu}
{d.name=Tony, d.surname=Maggs}
{d.name=Gerry, d.surname=Ashmore}
{d.name=Massimo, d.surname=Natili}
{d.name=Peter, d.surname=Monteverdi}
{d.name=Renato, d.surname=Pirocchi}
{d.name=Geoff, d.surname=Duke}
{d.name=John, d.surname=Campbell-Jones}
{d.name=Gaetano, d.surname=Starrabba}
{d.name=Ricardo, d.surname=Rodr�guez}
{d.name=Nino, d.surname=Vaccarella}
{d.name=Roberto, d.surname=Bussinello}
{d.name=Roberto, d.surname=Lippi}
{d.name=Ernesto, d.surname=Prinoth}
{d.name=Menato, d.surname=Boffa}
{d.name=Roger, d.surname=Penske}
{d.name=Peter, d.surname=Ryan}
{d.name=Hap, d.surname=Sharp}
{d.name=Walt, d.surname=Hansgen}
{d.name=Ken, d.surname=Miles}
{d.name=Ben, d.surname=Pon}
{d.name=Rob, d.surname=Slotemaker}
{d.name=Jo, d.surname=Siffert}
{d.name=Heinz, d.surname=Schiller}
{d.name=Peter, d.surname=Arundell}
{d.name=Carlo, d.surname=Abate}
{d.name=Tony, d.surname=Settember}
{d.name=Jay, d.surname=Chamberlain}
{d.name=Tony, d.surname=Shelly}
{d.name=Heini, d.surname=Walter}
{d.name=G�nther, d.surname=Seiffert}
{d.name=Kurt, d.surname=Kuhnke}
{d.name=Rob, d.surname=Schroeder}
{d.name=Timmy, d.surname=Mayer}
{d.name=Neville, d.surname=Lederle}
{d.name=John, d.surname=Love}
{d.name=Bruce, d.surname=Johnstone}
{d.name=Ernie, d.surname=Pieterse}
{d.name=Doug, d.surname=Serrurier}
{d.name=Mike, d.surname=Harris}
{d.name=Gary, d.surname=Hocking}
{d.name=Syd, d.surname=van der Vyver}
{d.name=Sam, d.surname=Tingle}
{d.name=Chris, d.surname=Amon}
{d.name=Ludovico, d.surname=Scarfiotti}
{d.name=Gerhard, d.surname=Mitter}
{d.name=Mike, d.surname=Hailwood}
{d.name=Bob, d.surname=Anderson}
{d.name=Ian, d.surname=Raby}
{d.name=Mike, d.surname=Spence}
{d.name=Ernesto, d.surname=Brambilla}
{d.name=Peter, d.surname=Broeker}
{d.name=Pedro, d.surname=Rodr�guez}
{d.name=Ernie, d.surname=de Vos}
{d.name=Mois�s, d.surname=Solana}
{d.name=Frank, d.surname=Dochnal}
{d.name=Thomas, d.surname=Monarch}
{d.name=Trevor, d.surname=Blokdyk}
{d.name=Brausch, d.surname=Niemann}
{d.name=Peter, d.surname=de Klerk}
{d.name=David, d.surname=Prophet}
{d.name=Paddy, d.surname=Driver}
{d.name=Peter, d.surname=Revson}
{d.name=John, d.surname=Taylor}
{d.name=Frank, d.surname=Gardner}
{d.name=Richard, d.surname=Attwood}
{d.name=Ronnie, d.surname=Bucknum}
{d.name=Jochen, d.surname=Rindt}
{d.name=Giacomo, d.surname=Russo}
{d.name=Jackie, d.surname=Stewart}
{d.name=Paul, d.surname=Hawkins}
{d.name=Clive, d.surname=Puzey}
{d.name=Jackie, d.surname=Pretorius}
{d.name=Dave, d.surname=Charlton}
{d.name=Ray, d.surname=Reed}
{d.name=David, d.surname=Clapham}
{d.name=Alex, d.surname=Blignaut}
{d.name=Denny, d.surname=Hulme}
{d.name=John, d.surname=Rhodes}
{d.name=Alan, d.surname=Rollinson}
{d.name=Brian, d.surname=Gubby}
{d.name=Giorgio, d.surname=Bassi}
{d.name=Bob, d.surname=Bondurant}
{d.name=Guy, d.surname=Ligier}
{d.name=Chris, d.surname=Irwin}
{d.name=Chris, d.surname=Lawrence}
{d.name=Luki, d.surname=Botha}
{d.name=Piers, d.surname=Courage}
{d.name=Johnny, d.surname=Servoz-Gavin}
{d.name=Jean-Pierre, d.surname=Beltoise}
{d.name=David, d.surname=Hobbs}
{d.name=Alan, d.surname=Rees}
{d.name=Silvio, d.surname=Moser}
{d.name=Jackie, d.surname=Oliver}
{d.name=Jacky, d.surname=Ickx}
{d.name=Brian, d.surname=Hart}
{d.name=Hubert, d.surname=Hahne}
{d.name=Kurt, d.surname=Ahrens}
{d.name=Jo, d.surname=Schlesser}
{d.name=Mike, d.surname=Fisher}
{d.name=Eppie, d.surname=Wietzes}
{d.name=Al, d.surname=Pease}
{d.name=Tom, d.surname=Jones}
{d.name=Jonathan, d.surname=Williams}
{d.name=Basil, d.surname=van Rooyen}
{d.name=Andrea, d.surname=de Adamich}
{d.name=Brian, d.surname=Redman}
{d.name=Vic, d.surname=Elford}
{d.name=Robin, d.surname=Widdows}
{d.name=Derek, d.surname=Bell}
{d.name=Henri, d.surname=Pescarolo}
{d.name=Bill, d.surname=Brack}
{d.name=Bobby, d.surname=Unser}
{d.name=Mario, d.surname=Andretti}
{d.name=John, d.surname=Miles}
{d.name=John, d.surname=Cordts}
{d.name=George, d.surname=Eaton}
{d.name=Rolf, d.surname=Stommelen}
{d.name=Alex, d.surname=Soler-Roig}
{d.name=Ronnie, d.surname=Peterson}
{d.name=Ignazio, d.surname=Giunti}
{d.name=Clay, d.surname=Regazzoni}
{d.name=Fran�ois, d.surname=Cevert}
{d.name=Peter, d.surname=Gethin}
{d.name=Emerson, d.surname=Fittipaldi}
{d.name=Tim, d.surname=Schenken}
{d.name=Nanni, d.surname=Galli}
{d.name=Reine, d.surname=Wisell}
{d.name=Gus, d.surname=Hutchison}
{d.name=Peter, d.surname=Westbury}
{d.name=Howden, d.surname=Ganley}
{d.name=Skip, d.surname=Barber}
{d.name=Gijs, d.surname=van Lennep}
{d.name=David, d.surname=Walker}
{d.name=Fran�ois, d.surname=Mazet}
{d.name=Max, d.surname=Jean}
{d.name=Mike, d.surname=Beuttler}
{d.name=Helmut, d.surname=Marko}
{d.name=Niki, d.surname=Lauda}
{d.name=Jean-Pierre, d.surname=Jarier}
{d.name=Mark, d.surname=Donohue}
{d.name=Chris, d.surname=Craft}
{d.name=John, d.surname=Cannon}
{d.name=Sam, d.surname=Posey}
{d.name=Carlos, d.surname=Reutemann}
{d.name=Carlos, d.surname=Pace}
{d.name=Wilson, d.surname=Fittipaldi}
{d.name=Patrick, d.surname=Depailler}
{d.name=Arturo, d.surname=Merzario}
{d.name=Fran�ois, d.surname=Migault}
{d.name=Jody, d.surname=Scheckter}
{d.name=Luiz, d.surname=Bueno}
{d.name=George, d.surname=Follmer}
{d.name=Eddie, d.surname=Keizan}
{d.name=James, d.surname=Hunt}
{d.name=David, d.surname=Purley}
{d.name=Rikky, d.surname=von Opel}
{d.name=John, d.surname=Watson}
{d.name=Jochen, d.surname=Mass}
{d.name=Roger, d.surname=Williamson}
{d.name=Graham, d.surname=McRae}
{d.name=Guy, d.surname=Edwards}
{d.name=Richard, d.surname=Robarts}
{d.name=Hans-Joachim, d.surname=Stuck}
{d.name=Vittorio, d.surname=Brambilla}
{d.name=Ian, d.surname=Scheckter}
{d.name=Tom, d.surname=Bels�}
{d.name=Vern, d.surname=Schuppan}
{d.name=Teddy, d.surname=Pilette}
{d.name=Tom, d.surname=Pryce}
{d.name=G�rard, d.surname=Larrousse}
{d.name=Leo, d.surname=Kinnunen}
{d.name=Bertil, d.surname=Roos}
{d.name=Jean-Pierre, d.surname=Jabouille}
{d.name=Jos�, d.surname=Dolhem}
{d.name=Lella, d.surname=Lombardi}
{d.name=John, d.surname=Nicholson}
{d.name=Mike, d.surname=Wilds}
{d.name=Ian, d.surname=Ashley}
{d.name=Jacques, d.surname=Laffite}
{d.name=Larry, d.surname=Perkins}
{d.name=Dieter, d.surname=Quester}
{d.name=Helmuth, d.surname=Koinigg}
{d.name=Carlo, d.surname=Facetti}
{d.name=Guy, d.surname=Tunmer}
{d.name=Bob, d.surname=Evans}
{d.name=Tony, d.surname=Brise}
{d.name=Roelof, d.surname=Wunderink}
{d.name=Alan, d.surname=Jones}
{d.name=Torsten, d.surname=Palm}
{d.name=Damien, d.surname=Magee}
{d.name=Hiroshi, d.surname=Fushida}
{d.name=Brian, d.surname=Henton}
{d.name=Dave, d.surname=Morgan}
{d.name=Jim, d.surname=Crawford}
{d.name=Harald, d.surname=Ertl}
{d.name=Tony, d.surname=Trimmer}
{d.name=Brett, d.surname=Lunger}
{d.name=Jo, d.surname=Vonlanthen}
{d.name=Renzo, d.surname=Zorzi}
{d.name=Michel, d.surname=Lecl�re}
{d.name=Ingo, d.surname=Hoffmann}
{d.name=Gunnar, d.surname=Nilsson}
{d.name=Loris, d.surname=Kessel}
{d.name=Emilio, d.surname=Zapico}
{d.name=Emilio, d.surname=de Villota}
{d.name=Patrick, d.surname=N�ve}
{d.name=Jac, d.surname=Nelleman}
{d.name=Divina, d.surname=Galica}
{d.name=Alessandro, d.surname=Pesenti-Rossi}
{d.name=Hans, d.surname=Binder}
{d.name=Boy, d.surname=Lunger}
{d.name=Conny, d.surname=Andersson}
{d.name=Otto, d.surname=Stuppacher}
{d.name=Alex, d.surname=Ribeiro}
{d.name=Warwick, d.surname=Brown}
{d.name=Noritake, d.surname=Takahara}
{d.name=Masahiro, d.surname=Hasemi}
{d.name=Kazuyoshi, d.surname=Hoshino}
{d.name=Rupert, d.surname=Keegan}
{d.name=Riccardo, d.surname=Patrese}
{d.name=Bernard, d.surname=de Dryver}
{d.name=Hector, d.surname=Rebaque}
{d.name=Mikko, d.surname=Kozarowitzky}
{d.name=Patrick, d.surname=Tambay}
{d.name=Gilles, d.surname=Villeneuve}
{d.name=Andy, d.surname=Sutcliffe}
{d.name=Brian, d.surname=McGuire}
{d.name=Hans, d.surname=Heyer}
{d.name=Michael, d.surname=Bleekemolen}
{d.name=Bruno, d.surname=Giacomelli}
{d.name=Lamberto, d.surname=Leoni}
{d.name=Giorgio, d.surname=Francia}
{d.name=Danny, d.surname=Ongais}
{d.name=Kunimitsu, d.surname=Takahashi}
{d.name=Didier, d.surname=Pironi}
{d.name=Eddie, d.surname=Cheever}
{d.name=Keke, d.surname=Rosberg}
{d.name=Ren�, d.surname=Arnoux}
{d.name=Derek, d.surname=Daly}
{d.name=Alberto, d.surname=Colombo}
{d.name=Geoff, d.surname=Lees}
{d.name=Nelson, d.surname=Piquet}
{d.name=Carlo, d.surname=Franchi}
{d.name=Bobby, d.surname=Rahal}
{d.name=Beppe, d.surname=Gabbiani}
{d.name=Elio, d.surname=de Angelis}
{d.name=Jan, d.surname=Lammers}
{d.name=Gianfranco, d.surname=Brancatelli}
{d.name=Patrick, d.surname=Gaillard}
{d.name=Marc, d.surname=Surer}
{d.name=Ricardo, d.surname=Zunino}
{d.name=Alain, d.surname=Prost}
{d.name=Dave, d.surname=Kennedy}
{d.name=Stefan, d.surname=Johansson}
{d.name=Stephen, d.surname=South}
{d.name=Tiff, d.surname=Needell}
{d.name=Desir�, d.surname=Wilson}
{d.name=Nigel, d.surname=Mansell}
{d.name=Mike, d.surname=Thackwell}
{d.name=Manfred, d.surname=Winkelhock}
{d.name=Andrea, d.surname=de Cesaris}
{d.name=Kevin, d.surname=Cogan}
{d.name=Chico, d.surname=Serra}
{d.name=Miguel �ngel, d.surname=Guerra}
{d.name=Siegfried, d.surname=Stohr}
{d.name=Eliseo, d.surname=Salazar}
{d.name=Ricardo, d.surname=Londo�o}
{d.name=Slim, d.surname=Borgudd}
{d.name=Michele, d.surname=Alboreto}
{d.name=Derek, d.surname=Warwick}
{d.name=Piercarlo, d.surname=Ghinzani}
{d.name=Jacques, d.surname=Villeneuve Sr.}
{d.name=Raul, d.surname=Boesel}
{d.name=Mauro, d.surname=Baldi}
{d.name=Riccardo, d.surname=Paletti}
{d.name=Roberto, d.surname=Guerrero}
{d.name=Teo, d.surname=Fabi}
{d.name=Roberto, d.surname=Moreno}
{d.name=Tommy, d.surname=Byrne}
{d.name=Danny, d.surname=Sullivan}
{d.name=Johnny, d.surname=Cecotto}
{d.name=Corrado, d.surname=Fabi}
{d.name=Jean-Louis, d.surname=Schlesser}
{d.name=Thierry, d.surname=Boutsen}
{d.name=Kenny, d.surname=Acheson}
{d.name=Jonathan, d.surname=Palmer}
{d.name=Martin, d.surname=Brundle}
{d.name=Fran�ois, d.surname=Hesnault}
{d.name=Philippe, d.surname=Alliot}
{d.name=Stefan, d.surname=Bellof}
{d.name=Ayrton, d.surname=Senna}
{d.name=Jo, d.surname=Gartner}
{d.name=Huub, d.surname=Rothengatter}
{d.name=Gerhard, d.surname=Berger}
{d.name=Pierluigi, d.surname=Martini}
{d.name=Philippe, d.surname=Streiff}
{d.name=Christian, d.surname=Danner}
{d.name=Ivan, d.surname=Capelli}
{d.name=Johnny, d.surname=Dumfries}
{d.name=Alessandro, d.surname=Nannini}
{d.name=Allen, d.surname=Berg}
{d.name=Alex, d.surname=Caffi}
{d.name=Satoru, d.surname=Nakajima}
{d.name=Pascal, d.surname=Fabre}
{d.name=Adri�n, d.surname=Campos}
{d.name=Gabriele, d.surname=Tarquini}
{d.name=Franco, d.surname=Forini}
{d.name=Nicola, d.surname=Larini}
{d.name=Yannick, d.surname=Dalmas}
{d.name=Stefano, d.surname=Modena}
{d.name=Luis, d.surname=P�rez-Sala}
{d.name=Maur�cio, d.surname=Gugelmin}
{d.name=Oscar, d.surname=Larrauri}
{d.name=Julian, d.surname=Bailey}
{d.name=Bernd, d.surname=Schneider}
{d.name=Aguri, d.surname=Suzuki}
{d.name=Pierre-Henri, d.surname=Raphanel}
{d.name=Johnny, d.surname=Herbert}
{d.name=Olivier, d.surname=Grouillard}
{d.name=Gregor, d.surname=Foitek}
{d.name=Volker, d.surname=Weidler}
{d.name=Joachim, d.surname=Winkelhock}
{d.name=Bertrand, d.surname=Gachot}
{d.name=Jean, d.surname=Alesi}
{d.name=Emanuele, d.surname=Pirro}
{d.name=�ric, d.surname=Bernard}
{d.name=Martin, d.surname=Donnelly}
{d.name=Enrico, d.surname=Bertaggia}
{d.name=Jyrki, d.surname=J�rvilehto}
{d.name=Paolo, d.surname=Barilla}
{d.name=Gianni, d.surname=Morbidelli}
{d.name=Claudio, d.surname=Langes}
{d.name=Gary, d.surname=Brabham}
{d.name=David, d.surname=Brabham}
{d.name=Mika, d.surname=H�kkinen}
{d.name=Mark, d.surname=Blundell}
{d.name=�rik, d.surname=Comas}
{d.name=Pedro, d.surname=Chaves}
{d.name=Eric, d.surname=van de Poele}
{d.name=Fabrizio, d.surname=Barbazza}
{d.name=Michael, d.surname=Bartels}
{d.name=Michael, d.surname=Schumacher}
{d.name=Alessandro, d.surname=Zanardi}
{d.name=Karl, d.surname=Wendlinger}
{d.name=Naoki, d.surname=Hattori}
{d.name=Ukyo, d.surname=Katayama}
{d.name=Christian, d.surname=Fittipaldi}
{d.name=Paul, d.surname=Belmondo}
{d.name=Andrea, d.surname=Chiesa}
{d.name=Giovanna, d.surname=Amati}
{d.name=Damon, d.surname=Hill}
{d.name=Perry, d.surname=McCarthy}
{d.name=Emanuele, d.surname=Naspetti}
{d.name=Rubens, d.surname=Barrichello}
{d.name=Luca, d.surname=Badoer}
{d.name=Michael, d.surname=Andretti}
{d.name=Pedro, d.surname=Lamy}
{d.name=Marco, d.surname=Apicella}
{d.name=Eddie, d.surname=Irvine}
{d.name=Toshio, d.surname=Suzuki}
{d.name=Jean-Marc, d.surname=Gounon}
{d.name=Olivier, d.surname=Panis}
{d.name=Jos, d.surname=Verstappen}
{d.name=Heinz-Harald, d.surname=Frentzen}
{d.name=Olivier, d.surname=Beretta}
{d.name=Roland, d.surname=Ratzenberger}
{d.name=David, d.surname=Coulthard}
{d.name=Andrea, d.surname=Montermini}
{d.name=Philippe, d.surname=Adams}
{d.name=Domenico, d.surname=Schiattarella}
{d.name=Hideki, d.surname=Noda}
{d.name=Mika, d.surname=Salo}
{d.name=Franck, d.surname=Lagorce}
{d.name=Taki, d.surname=Inoue}
{d.name=Jean-Denis, d.surname=D�l�traz}
{d.name=Pedro, d.surname=Diniz}
{d.name=Jean-Christophe, d.surname=Boullion}
{d.name=Massimiliano, d.surname=Papis}
{d.name=Giovanni, d.surname=Lavaggi}
{d.name=Jan, d.surname=Magnussen}
{d.name=Jacques, d.surname=Villeneuve}
{d.name=Ricardo, d.surname=Rosset}
{d.name=Giancarlo, d.surname=Fisichella}
{d.name=Tarso, d.surname=Marques}
{d.name=Shinji, d.surname=Nakano}
{d.name=Jarno, d.surname=Trulli}
{d.name=Ralf, d.surname=Schumacher}
{d.name=Vincenzo, d.surname=Sospiri}
{d.name=Alexander, d.surname=Wurz}
{d.name=Norberto, d.surname=Fontana}
{d.name=Esteban, d.surname=Tuero}
{d.name=Toranosuke, d.surname=Takagi}
{d.name=Pedro, d.surname=de la Rosa}
{d.name=Ricardo, d.surname=Zonta}
{d.name=Marc, d.surname=Gen�}
{d.name=St�phane, d.surname=Sarrazin}
{d.name=Nick, d.surname=Heidfeld}
{d.name=Jenson, d.surname=Button}
{d.name=Gast�n, d.surname=Mazzacane}
{d.name=Luciano, d.surname=Burti}
{d.name=Kimi, d.surname=R�ikk�nen}
{d.name=Fernando, d.surname=Alonso}
{d.name=Juan, d.surname=Pablo Montoya}
{d.name=Enrique, d.surname=Bernoldi}
{d.name=Tom�, d.surname=Enge}
{d.name=Alex, d.surname=Yoong}
{d.name=Mark, d.surname=Webber}
{d.name=Takuma, d.surname=Sato}
{d.name=Felipe, d.surname=Massa}
{d.name=Allan, d.surname=McNish}
{d.name=Anthony, d.surname=Davidson}
{d.name=Ant�nio, d.surname=Pizzonia}
{d.name=Justin, d.surname=Wilson}
{d.name=Cristiano, d.surname=da Matta}
{d.name=Ralph, d.surname=Firman}
{d.name=Nicolas, d.surname=Kiesa}
{d.name=Zsolt, d.surname=Baumgartner}
{d.name=Christian, d.surname=Klien}
{d.name=Giorgio, d.surname=Pantano}
{d.name=Gianmaria, d.surname=Bruni}
{d.name=Timo, d.surname=Glock}
{d.name=Narain, d.surname=Karthikeyan}
{d.name=Tiago, d.surname=Monteiro}
{d.name=Patrick, d.surname=Friesacher}
{d.name=Christijan, d.surname=Albers}
{d.name=Vitantonio, d.surname=Liuzzi}
{d.name=Robert, d.surname=Doornbos}
{d.name=Nico, d.surname=Rosberg}
{d.name=Scott, d.surname=Speed}
{d.name=Yuji, d.surname=Ide}
{d.name=Franck, d.surname=Montagny}
{d.name=Sakon, d.surname=Yamamoto}
{d.name=Robert, d.surname=Kubica}
{d.name=Lewis, d.surname=Hamilton}
{d.name=Heikki, d.surname=Kovalainen}
{d.name=Adrian, d.surname=Sutil}
{d.name=Sebastian, d.surname=Vettel}
{d.name=Markus, d.surname=Winkelhock}
{d.name=Kazuki, d.surname=Nakajima}
{d.name=S�bastien, d.surname=Bourdais}
{d.name=Nelson, d.surname=Piquet Jr.}
{d.name=S�bastien, d.surname=Buemi}
{d.name=Jaime, d.surname=Alguersuari}
{d.name=Romain, d.surname=Grosjean}
{d.name=Kamui, d.surname=Kobayashi}
{d.name=Nico, d.surname=H�lkenberg}
{d.name=Bruno, d.surname=Senna}
{d.name=Vitaly, d.surname=Petrov}
{d.name=Lucas, d.surname=di Grassi}
{d.name=Karun, d.surname=Chandhok}
{d.name=Paul, d.surname=di Resta}
{d.name=J�r�me, d.surname=d'Ambrosio}
{d.name=Pastor, d.surname=Maldonado}
{d.name=Sergio, d.surname=P�rez}
{d.name=Daniel, d.surname=Ricciardo}
{d.name=Jean-�ric, d.surname=Vergne}
{d.name=Charles, d.surname=Pic}
{d.name=Esteban, d.surname=Guti�rrez}
{d.name=Valtteri, d.surname=Bottas}
{d.name=Jules, d.surname=Bianchi}
{d.name=Max, d.surname=Chilton}
{d.name=Giedo, d.surname=van der Garde}
{d.name=Kevin, d.surname=Magnussen}
{d.name=Daniil, d.surname=Kvyat}
{d.name=Marcus, d.surname=Ericsson}
{d.name=Andr�, d.surname=Lotterer}
{d.name=Will, d.surname=Stevens}
{d.name=Felipe, d.surname=Nasr}
{d.name=Carlos, d.surname=Sainz}
{d.name=Max, d.surname=Verstappen}
{d.name=Roberto, d.surname=Merhi}
{d.name=Alexander, d.surname=Rossi}
{d.name=Jolyon, d.surname=Palmer}
{d.name=Pascal, d.surname=Wehrlein}
{d.name=Rio, d.surname=Haryanto}
{d.name=Stoffel, d.surname=Vandoorne}
{d.name=Esteban, d.surname=Ocon}
{d.name=Antonio, d.surname=Giovinazzi}
{d.name=Lance, d.surname=Stroll}
{d.name=Pierre, d.surname=Gasly}
{d.name=Brendon, d.surname=Hartley}
{d.name=Charles, d.surname=Leclerc}
{d.name=Sergey, d.surname=Sirotkin}
{d.name=Lando, d.surname=Norris}
{d.name=Alexander, d.surname=Albon}
{d.name=George, d.surname=Russell}

# Número de corridas por ano

{Year=1950, RaceCount=7}
{Year=1951, RaceCount=8}
{Year=1952, RaceCount=8}
{Year=1953, RaceCount=9}
{Year=1954, RaceCount=9}
{Year=1955, RaceCount=7}
{Year=1956, RaceCount=8}
{Year=1957, RaceCount=8}
{Year=1958, RaceCount=11}
{Year=1959, RaceCount=9}
{Year=1960, RaceCount=10}
{Year=1961, RaceCount=8}
{Year=1962, RaceCount=9}
{Year=1963, RaceCount=10}
{Year=1964, RaceCount=10}
{Year=1965, RaceCount=10}
{Year=1966, RaceCount=9}
{Year=1967, RaceCount=11}
{Year=1968, RaceCount=12}
{Year=1969, RaceCount=11}
{Year=1970, RaceCount=13}
{Year=1971, RaceCount=11}
{Year=1972, RaceCount=12}
{Year=1973, RaceCount=15}
{Year=1974, RaceCount=15}
{Year=1975, RaceCount=14}
{Year=1976, RaceCount=16}
{Year=1977, RaceCount=17}
{Year=1978, RaceCount=16}
{Year=1979, RaceCount=15}
{Year=1980, RaceCount=14}
{Year=1981, RaceCount=15}
{Year=1982, RaceCount=16}
{Year=1983, RaceCount=15}
{Year=1984, RaceCount=16}
{Year=1985, RaceCount=16}
{Year=1986, RaceCount=16}
{Year=1987, RaceCount=16}
{Year=1988, RaceCount=16}
{Year=1989, RaceCount=16}
{Year=1990, RaceCount=16}
{Year=1991, RaceCount=16}
{Year=1992, RaceCount=16}
{Year=1993, RaceCount=16}
{Year=1994, RaceCount=16}
{Year=1995, RaceCount=17}
{Year=1996, RaceCount=16}
{Year=1997, RaceCount=17}
{Year=1998, RaceCount=16}
{Year=1999, RaceCount=16}
{Year=2000, RaceCount=17}
{Year=2001, RaceCount=17}
{Year=2002, RaceCount=17}
{Year=2003, RaceCount=16}
{Year=2004, RaceCount=18}
{Year=2005, RaceCount=19}
{Year=2006, RaceCount=18}
{Year=2007, RaceCount=17}
{Year=2008, RaceCount=18}
{Year=2009, RaceCount=17}
{Year=2010, RaceCount=19}
{Year=2011, RaceCount=19}
{Year=2012, RaceCount=20}
{Year=2013, RaceCount=19}
{Year=2014, RaceCount=19}
{Year=2015, RaceCount=19}
{Year=2016, RaceCount=21}
{Year=2017, RaceCount=20}
{Year=2018, RaceCount=21}
{Year=2019, RaceCount=21}

# Número de pilotos que correu por cada equipa

{c.name=Alfa Romeo, count(d)=20}
{c.name=Talbot-Lago, count(d)=18}
{c.name=ERA, count(d)=7}
{c.name=Maserati, count(d)=92}
{c.name=Alta, count(d)=4}
{c.name=Ferrari, count(d)=96}
{c.name=Simca, count(d)=11}
{c.name=Cooper, count(d)=36}
{c.name=Kurtis Kraft, count(d)=87}
{c.name=Deidt, count(d)=5}
{c.name=Moore, count(d)=3}
{c.name=Lesovsky, count(d)=11}
{c.name=Nichels, count(d)=4}
{c.name=Marchese, count(d)=2}
{c.name=Stevens, count(d)=10}
{c.name=Langley, count(d)=1}
{c.name=Ewing, count(d)=3}
{c.name=Rae, count(d)=1}
{c.name=Olson, count(d)=1}
{c.name=Wetteroth, count(d)=1}
{c.name=Snowberger, count(d)=1}
{c.name=Adams, count(d)=2}
{c.name=Watson, count(d)=15}
{c.name=Milano, count(d)=1}
{c.name=HWM, count(d)=15}
{c.name=Veritas, count(d)=15}
{c.name=Sherman, count(d)=2}
{c.name=Schroeder, count(d)=8}
{c.name=Kuzma, count(d)=23}
{c.name=Pawl, count(d)=4}
{c.name=Hall, count(d)=1}
{c.name=Bromme, count(d)=4}
{c.name=Trevis, count(d)=4}
{c.name=BRM, count(d)=70}
{c.name=OSCA, count(d)=5}
{c.name=Gordini, count(d)=23}
{c.name=Frazer Nash, count(d)=2}
{c.name=AFM, count(d)=5}
{c.name=Aston Butterworth, count(d)=2}
{c.name=Connaught, count(d)=29}
{c.name=BMW, count(d)=4}
{c.name=Cisitalia, count(d)=1}
{c.name=Turner, count(d)=1}
{c.name=Del Roy, count(d)=1}
{c.name=EMW, count(d)=1}
{c.name=Phillips, count(d)=3}
{c.name=Pankratz, count(d)=1}
{c.name=Mercedes, count(d)=11}
{c.name=Vanwall, count(d)=12}
{c.name=Klenk, count(d)=1}
{c.name=Lancia, count(d)=4}
{c.name=Epperly, count(d)=10}
{c.name=Arzani-Volpini, count(d)=1}
{c.name=Bugatti, count(d)=1}
{c.name=Emeryson, count(d)=7}
{c.name=Dunn, count(d)=2}
{c.name=Porsche, count(d)=17}
{c.name=Team Lotus, count(d)=61}
{c.name=Cooper-Climax, count(d)=58}
{c.name=Cooper-Maserati, count(d)=35}
{c.name=Elder, count(d)=1}
{c.name=Christensen, count(d)=2}
{c.name=Sutton, count(d)=1}
{c.name=Aston Martin, count(d)=3}
{c.name=Cooper-Borgward, count(d)=3}
{c.name=JBW, count(d)=1}
{c.name=Fry, count(d)=1}
{c.name=Cooper-OSCA, count(d)=1}
{c.name=Tec-Mec, count(d)=1}
{c.name=Behra-Porsche, count(d)=2}
{c.name=Scarab, count(d)=3}
{c.name=Cooper-Castellotti, count(d)=4}
{c.name=Meskowski, count(d)=2}
{c.name=Lotus-Climax, count(d)=55}
{c.name=De Tomaso-Osca, count(d)=2}
{c.name=Gilby, count(d)=2}
{c.name=Ferguson, count(d)=2}
{c.name=MBM, count(d)=1}
{c.name=Lotus-Maserati, count(d)=1}
{c.name=De Tomaso-Alfa Romeo, count(d)=2}
{c.name=Lola, count(d)=25}
{c.name=Lotus-BRM, count(d)=31}
{c.name=ENB, count(d)=1}
{c.name=Brabham, count(d)=49}
{c.name=De Tomaso, count(d)=4}
{c.name=Lotus-Borgward, count(d)=1}
{c.name=LDS, count(d)=2}
{c.name=Cooper-Alfa Romeo, count(d)=1}
{c.name=ATS, count(d)=16}
{c.name=Scirocco, count(d)=3}
{c.name=BRP, count(d)=2}
{c.name=De Tomaso-Ferrari, count(d)=1}
{c.name=Stebro, count(d)=2}
{c.name=Lotus-Ford, count(d)=19}
{c.name=Brabham-Climax, count(d)=13}
{c.name=Brabham-BRM, count(d)=9}
{c.name=Brabham-Ford, count(d)=18}
{c.name=Honda, count(d)=8}
{c.name=Derrington, count(d)=1}
{c.name=LDS-Alfa Romeo, count(d)=2}
{c.name=Cooper-Ford, count(d)=2}
{c.name=LDS-Climax, count(d)=2}
{c.name=RE, count(d)=1}
{c.name=Brabham-Repco, count(d)=11}
{c.name=McLaren-Ford, count(d)=10}
{c.name=Eagle-Climax, count(d)=5}
{c.name=McLaren-Serenissima, count(d)=1}
{c.name=Cooper-Ferrari, count(d)=1}
{c.name=Shannon, count(d)=1}
{c.name=Eagle-Weslake, count(d)=4}
{c.name=McLaren-BRM, count(d)=3}
{c.name=Matra, count(d)=6}
{c.name=Cooper-ATS, count(d)=1}
{c.name=Protos, count(d)=2}
{c.name=Matra-Ford, count(d)=3}
{c.name=Cooper-BRM, count(d)=6}
{c.name=McLaren, count(d)=53}
{c.name=BRM-Ford, count(d)=1}
{c.name=March, count(d)=48}
{c.name=McLaren-Alfa Romeo, count(d)=2}
{c.name=Bellasi, count(d)=1}
{c.name=Surtees, count(d)=37}
{c.name=Tyrrell, count(d)=47}
{c.name=March-Ford, count(d)=11}
{c.name=March-Alfa Romeo, count(d)=3}
{c.name=Lotus-Pratt Camp Whitney, count(d)=3}
{c.name=Tecno, count(d)=3}
{c.name=Politoys, count(d)=1}
{c.name=Connew, count(d)=1}
{c.name=Iso Marlboro, count(d)=13}
{c.name=Shadow, count(d)=21}
{c.name=Ensign, count(d)=25}
{c.name=Hesketh, count(d)=15}
{c.name=Trojan, count(d)=1}
{c.name=Amon, count(d)=2}
{c.name=Token, count(d)=3}
{c.name=Lyncar, count(d)=1}
{c.name=Maki, count(d)=3}
{c.name=Parnelli, count(d)=1}
{c.name=Penske, count(d)=7}
{c.name=Shadow-Ford, count(d)=2}
{c.name=Williams, count(d)=56}
{c.name=Fittipaldi, count(d)=7}
{c.name=Embassy Hill, count(d)=6}
{c.name=Shadow-Matra, count(d)=1}
{c.name=Wolf, count(d)=10}
{c.name=Brabham-Alfa Romeo, count(d)=6}
{c.name=Ligier, count(d)=28}
{c.name=Boro, count(d)=2}
{c.name=Kojima, count(d)=3}
{c.name=LEC, count(d)=1}
{c.name=Renault, count(d)=25}
{c.name=McGuire, count(d)=1}
{c.name=Apollon, count(d)=1}
{c.name=Merzario, count(d)=3}
{c.name=Theodore, count(d)=10}
{c.name=Arrows, count(d)=29}
{c.name=Martini, count(d)=1}
{c.name=Kauhsen, count(d)=1}
{c.name=Rebaque, count(d)=1}
{c.name=Osella, count(d)=18}
{c.name=Toleman, count(d)=9}
{c.name=RAM, count(d)=8}
{c.name=Spirit, count(d)=3}
{c.name=Minardi, count(d)=37}
{c.name=Zakspeed, count(d)=7}
{c.name=Benetton, count(d)=17}
{c.name=AGS, count(d)=10}
{c.name=Larrousse, count(d)=13}
{c.name=Coloni, count(d)=8}
{c.name=Rial, count(d)=6}
{c.name=Euro Brun, count(d)=5}
{c.name=Dallara, count(d)=6}
{c.name=Onyx, count(d)=4}
{c.name=Leyton House, count(d)=3}
{c.name=Life, count(d)=2}
{c.name=Lambo, count(d)=2}
{c.name=Jordan, count(d)=30}
{c.name=Footwork, count(d)=11}
{c.name=Fondmetal, count(d)=4}
{c.name=Andrea Moda, count(d)=2}
{c.name=Sauber, count(d)=28}
{c.name=Simtek, count(d)=7}
{c.name=Pacific, count(d)=5}
{c.name=Forti, count(d)=4}
{c.name=Prost, count(d)=9}
{c.name=Stewart, count(d)=4}
{c.name=BAR, count(d)=7}
{c.name=Jaguar, count(d)=8}
{c.name=Toyota, count(d)=9}
{c.name=Red Bull, count(d)=11}
{c.name=Toro Rosso, count(d)=14}
{c.name=BMW Sauber, count(d)=4}
{c.name=MF1, count(d)=2}
{c.name=Super Aguri, count(d)=5}
{c.name=Spyker MF1, count(d)=2}
{c.name=Spyker, count(d)=4}
{c.name=Force India, count(d)=7}
{c.name=Brawn, count(d)=2}
{c.name=Lotus, count(d)=3}
{c.name=HRT, count(d)=8}
{c.name=Virgin, count(d)=3}
{c.name=Lotus F1, count(d)=5}
{c.name=Marussia, count(d)=4}
{c.name=Caterham, count(d)=8}
{c.name=Manor Marussia, count(d)=6}
{c.name=Haas F1 Team, count(d)=3}
{c.name=Racing Point, count(d)=2}

# Pilotos que participaram numa corrida num dado ano

{d.name=Kevin, d.surname=Magnussen}
{d.name=Romain, d.surname=Grosjean}
{d.name=Antonio, d.surname=Giovinazzi}
{d.name=Sergio, d.surname=P�rez}
{d.name=Sebastian, d.surname=Vettel}
{d.name=Robert, d.surname=Kubica}
{d.name=George, d.surname=Russell}
{d.name=Lance, d.surname=Stroll}
{d.name=Alexander, d.surname=Albon}
{d.name=Lando, d.surname=Norris}
{d.name=Nico, d.surname=H�lkenberg}
{d.name=Daniil, d.surname=Kvyat}
{d.name=Kimi, d.surname=R�ikk�nen}
{d.name=Daniel, d.surname=Ricciardo}
{d.name=Carlos, d.surname=Sainz}
{d.name=Max, d.surname=Verstappen}
{d.name=Pierre, d.surname=Gasly}
{d.name=Charles, d.surname=Leclerc}
{d.name=Valtteri, d.surname=Bottas}
{d.name=Lewis, d.surname=Hamilton}

# Vitórias de um piloto

{RaceName=San Marino Grand Prix, RaceYear=1987, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=San Marino Grand Prix, RaceYear=1994, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Pacific Grand Prix, RaceYear=1994, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1994, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Australian Grand Prix, RaceYear=1993, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Japanese Grand Prix, RaceYear=1993, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Portuguese Grand Prix, RaceYear=1993, StartingGrid=6, FinalPosition=1, Status=Finished}
{RaceName=Italian Grand Prix, RaceYear=1993, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Belgian Grand Prix, RaceYear=1993, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Hungarian Grand Prix, RaceYear=1993, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=German Grand Prix, RaceYear=1993, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=British Grand Prix, RaceYear=1993, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=French Grand Prix, RaceYear=1993, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Canadian Grand Prix, RaceYear=1993, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Monaco Grand Prix, RaceYear=1993, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=Spanish Grand Prix, RaceYear=1993, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=San Marino Grand Prix, RaceYear=1993, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=European Grand Prix, RaceYear=1993, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1993, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=South African Grand Prix, RaceYear=1993, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Australian Grand Prix, RaceYear=1992, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=Japanese Grand Prix, RaceYear=1992, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Portuguese Grand Prix, RaceYear=1992, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Italian Grand Prix, RaceYear=1992, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Belgian Grand Prix, RaceYear=1992, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=Hungarian Grand Prix, RaceYear=1992, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=German Grand Prix, RaceYear=1992, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=British Grand Prix, RaceYear=1992, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=French Grand Prix, RaceYear=1992, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Canadian Grand Prix, RaceYear=1992, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=Monaco Grand Prix, RaceYear=1992, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=San Marino Grand Prix, RaceYear=1992, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Spanish Grand Prix, RaceYear=1992, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1992, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Mexican Grand Prix, RaceYear=1992, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=South African Grand Prix, RaceYear=1992, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Australian Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Japanese Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Spanish Grand Prix, RaceYear=1991, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Portuguese Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Italian Grand Prix, RaceYear=1991, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Belgian Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Hungarian Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=German Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=British Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=French Grand Prix, RaceYear=1991, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=Mexican Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Canadian Grand Prix, RaceYear=1991, StartingGrid=8, FinalPosition=1, Status=Finished}
{RaceName=Monaco Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=San Marino Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=United States Grand Prix, RaceYear=1991, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Australian Grand Prix, RaceYear=1990, StartingGrid=7, FinalPosition=1, Status=Finished}
{RaceName=Japanese Grand Prix, RaceYear=1990, StartingGrid=6, FinalPosition=1, Status=Finished}
{RaceName=Spanish Grand Prix, RaceYear=1990, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Portuguese Grand Prix, RaceYear=1990, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Italian Grand Prix, RaceYear=1990, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Belgian Grand Prix, RaceYear=1990, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Hungarian Grand Prix, RaceYear=1990, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=German Grand Prix, RaceYear=1990, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=British Grand Prix, RaceYear=1990, StartingGrid=5, FinalPosition=1, Status=Finished}
{RaceName=French Grand Prix, RaceYear=1990, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=Mexican Grand Prix, RaceYear=1990, StartingGrid=13, FinalPosition=1, Status=Finished}
{RaceName=Canadian Grand Prix, RaceYear=1990, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Monaco Grand Prix, RaceYear=1990, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=San Marino Grand Prix, RaceYear=1990, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1990, StartingGrid=6, FinalPosition=1, Status=Finished}
{RaceName=United States Grand Prix, RaceYear=1990, StartingGrid=5, FinalPosition=1, Status=Finished}
{RaceName=Australian Grand Prix, RaceYear=1989, StartingGrid=5, FinalPosition=1, Status=Finished}
{RaceName=Japanese Grand Prix, RaceYear=1989, StartingGrid=6, FinalPosition=1, Status=Finished}
{RaceName=Spanish Grand Prix, RaceYear=1989, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Portuguese Grand Prix, RaceYear=1989, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Italian Grand Prix, RaceYear=1989, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=Belgian Grand Prix, RaceYear=1989, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Hungarian Grand Prix, RaceYear=1989, StartingGrid=12, FinalPosition=1, Status=Finished}
{RaceName=German Grand Prix, RaceYear=1989, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=British Grand Prix, RaceYear=1989, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=French Grand Prix, RaceYear=1989, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Canadian Grand Prix, RaceYear=1989, StartingGrid=6, FinalPosition=1, Status=Finished}
{RaceName=United States Grand Prix, RaceYear=1989, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Mexican Grand Prix, RaceYear=1989, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Monaco Grand Prix, RaceYear=1989, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=San Marino Grand Prix, RaceYear=1989, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1989, StartingGrid=6, FinalPosition=1, Status=Finished}
{RaceName=Australian Grand Prix, RaceYear=1988, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Japanese Grand Prix, RaceYear=1988, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Spanish Grand Prix, RaceYear=1988, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Portuguese Grand Prix, RaceYear=1988, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Italian Grand Prix, RaceYear=1988, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=Belgian Grand Prix, RaceYear=1988, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Hungarian Grand Prix, RaceYear=1988, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=German Grand Prix, RaceYear=1988, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=British Grand Prix, RaceYear=1988, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=French Grand Prix, RaceYear=1988, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Detroit Grand Prix, RaceYear=1988, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Canadian Grand Prix, RaceYear=1988, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Mexican Grand Prix, RaceYear=1988, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Monaco Grand Prix, RaceYear=1988, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=San Marino Grand Prix, RaceYear=1988, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1988, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=Australian Grand Prix, RaceYear=1987, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Japanese Grand Prix, RaceYear=1987, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Mexican Grand Prix, RaceYear=1987, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Spanish Grand Prix, RaceYear=1987, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Portuguese Grand Prix, RaceYear=1987, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=Italian Grand Prix, RaceYear=1987, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Austrian Grand Prix, RaceYear=1987, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Hungarian Grand Prix, RaceYear=1987, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=German Grand Prix, RaceYear=1987, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=British Grand Prix, RaceYear=1987, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=French Grand Prix, RaceYear=1987, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Detroit Grand Prix, RaceYear=1987, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Monaco Grand Prix, RaceYear=1987, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Belgian Grand Prix, RaceYear=1987, StartingGrid=6, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1984, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=South African Grand Prix, RaceYear=1984, StartingGrid=8, FinalPosition=1, Status=Finished}
{RaceName=Belgian Grand Prix, RaceYear=1984, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=San Marino Grand Prix, RaceYear=1984, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=French Grand Prix, RaceYear=1984, StartingGrid=9, FinalPosition=1, Status=Finished}
{RaceName=Monaco Grand Prix, RaceYear=1984, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Canadian Grand Prix, RaceYear=1984, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Detroit Grand Prix, RaceYear=1984, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Dallas Grand Prix, RaceYear=1984, StartingGrid=8, FinalPosition=1, Status=Finished}
{RaceName=British Grand Prix, RaceYear=1984, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=German Grand Prix, RaceYear=1984, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Austrian Grand Prix, RaceYear=1984, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=Dutch Grand Prix, RaceYear=1984, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=European Grand Prix, RaceYear=1984, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Portuguese Grand Prix, RaceYear=1984, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1985, StartingGrid=6, FinalPosition=1, Status=Finished}
{RaceName=Portuguese Grand Prix, RaceYear=1985, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=San Marino Grand Prix, RaceYear=1985, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=Monaco Grand Prix, RaceYear=1985, StartingGrid=5, FinalPosition=1, Status=Finished}
{RaceName=Canadian Grand Prix, RaceYear=1985, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=Detroit Grand Prix, RaceYear=1985, StartingGrid=5, FinalPosition=1, Status=Finished}
{RaceName=French Grand Prix, RaceYear=1985, StartingGrid=5, FinalPosition=1, Status=Finished}
{RaceName=British Grand Prix, RaceYear=1985, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=German Grand Prix, RaceYear=1985, StartingGrid=8, FinalPosition=1, Status=Finished}
{RaceName=Austrian Grand Prix, RaceYear=1985, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Dutch Grand Prix, RaceYear=1985, StartingGrid=10, FinalPosition=1, Status=Finished}
{RaceName=Italian Grand Prix, RaceYear=1985, StartingGrid=5, FinalPosition=1, Status=Finished}
{RaceName=Belgian Grand Prix, RaceYear=1985, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=European Grand Prix, RaceYear=1985, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=South African Grand Prix, RaceYear=1985, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Australian Grand Prix, RaceYear=1985, StartingGrid=3, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1986, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Spanish Grand Prix, RaceYear=1986, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=San Marino Grand Prix, RaceYear=1986, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=Monaco Grand Prix, RaceYear=1986, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Belgian Grand Prix, RaceYear=1986, StartingGrid=5, FinalPosition=1, Status=Finished}
{RaceName=Canadian Grand Prix, RaceYear=1986, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=Detroit Grand Prix, RaceYear=1986, StartingGrid=1, FinalPosition=1, Status=Finished}
{RaceName=French Grand Prix, RaceYear=1986, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=British Grand Prix, RaceYear=1986, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=German Grand Prix, RaceYear=1986, StartingGrid=5, FinalPosition=1, Status=Finished}
{RaceName=Hungarian Grand Prix, RaceYear=1986, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Austrian Grand Prix, RaceYear=1986, StartingGrid=5, FinalPosition=1, Status=Finished}
{RaceName=Italian Grand Prix, RaceYear=1986, StartingGrid=6, FinalPosition=1, Status=Finished}
{RaceName=Portuguese Grand Prix, RaceYear=1986, StartingGrid=2, FinalPosition=1, Status=Finished}
{RaceName=Mexican Grand Prix, RaceYear=1986, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=Australian Grand Prix, RaceYear=1986, StartingGrid=4, FinalPosition=1, Status=Finished}
{RaceName=Brazilian Grand Prix, RaceYear=1987, StartingGrid=5, FinalPosition=1, Status=Finished}

# 10 Pilotos com mais corridas

{d.name=Rubens, d.surname=Barrichello, numRaces=326}
{d.name=Kimi, d.surname=R�ikk�nen, numRaces=315}
{d.name=Fernando, d.surname=Alonso, numRaces=314}
{d.name=Jenson, d.surname=Button, numRaces=309}
{d.name=Michael, d.surname=Schumacher, numRaces=308}
{d.name=Felipe, d.surname=Massa, numRaces=271}
{d.name=Riccardo, d.surname=Patrese, numRaces=257}
{d.name=Jarno, d.surname=Trulli, numRaces=256}
{d.name=Lewis, d.surname=Hamilton, numRaces=250}
{d.name=David, d.surname=Coulthard, numRaces=247}

# 5 Circuitos com mais corridas

{c.name=Autodromo Nazionale di Monza, numRaces=69}
{c.name=Circuit de Monaco, numRaces=66}
{c.name=Silverstone Circuit, numRaces=53}
{c.name=Circuit de Spa-Francorchamps, numRaces=52}
{c.name=N�rburgring, numRaces=40}

# 5 corridas com menos pilotos a terminar

{r.name=Monaco Grand Prix, r.year=1966, numFinishers=4}
{r.name=Detroit Grand Prix, r.year=1984, numFinishers=5}
{r.name=Monaco Grand Prix, r.year=1968, numFinishers=5}
{r.name=Belgian Grand Prix, r.year=1966, numFinishers=5}
{r.name=German Grand Prix, r.year=1956, numFinishers=5}

# Construtores com mais Vitórias

{c.name=Ferrari, numWins=6620}
{c.name=McLaren, numWins=6016}
{c.name=Williams, numWins=5968}

# Pilotos com mais corridas não terminadas

{d.name=Riccardo, d.surname=Patrese, numDNF=5654}
{d.name=Michael, d.surname=Schumacher, numDNF=4899}
{d.name=Rubens, d.surname=Barrichello, numDNF=4847}
{d.name=Michele, d.surname=Alboreto, numDNF=4842}
{d.name=Andrea, d.surname=de Cesaris, numDNF=4806}
{d.name=Nelson, d.surname=Piquet, numDNF=4566}
{d.name=Gerhard, d.surname=Berger, numDNF=4507}
{d.name=Alain, d.surname=Prost, numDNF=4495}
{d.name=Nigel, d.surname=Mansell, numDNF=4310}
{d.name=Jean, d.surname=Alesi, numDNF=3851}